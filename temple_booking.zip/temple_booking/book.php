<?php
require_once "includes/config.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: auth/login.php");
    exit;
}

$user_id = $_SESSION["id"];
$error = "";

// 1. Handle submission from temple.php form
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['flexible_book'])) {
    $-temple_id = intval($_POST['temple_id']);
    $booking_date = trim($_POST['booking_date']);
    $booking_time = trim($_POST['booking_time']);
    $booking_type = trim($_POST['booking_type']);
    $num_persons = intval($_POST['num_persons']);
    
    $price = ($booking_type == 'Pooja') ? 501.00 : 0.00;
    
    // Find or create slot
    $stmt = $pdo->prepare("SELECT id, available_capacity FROM slots WHERE temple_id=? AND slot_date=? AND start_time=? AND type=?");
    $stmt->execute([$temple_id, $booking_date, $booking_time, $booking_type]);
    $slot = $stmt->fetch();
    
    if ($slot) {
        $slot_id = $slot['id'];
        if ($slot['available_capacity'] < $num_persons) {
            $error = "Not enough capacity available at this exact time. Please try another time.";
        }
    } else {
        // Create dynamic slot
        $end_time = date('H:i:s', strtotime($booking_time) + 3600); // 1 hour duration
        $insert_slot = $pdo->prepare("INSERT INTO slots (temple_id, slot_date, start_time, end_time, total_capacity, available_capacity, type, price) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $insert_slot->execute([$temple_id, $booking_date, $booking_time, $end_time, 100, 100, $booking_type, $price]);
        $slot_id = $pdo->lastInsertId();
    }
    
    if (empty($error)) {
        // Create booking
        $total_amount = $num_persons * $price;
        $insert_sql = "INSERT INTO bookings (user_id, temple_id, slot_id, num_persons, total_amount, status, payment_status) 
                       VALUES (:user_id, :temple_id, :slot_id, :num_persons, :total_amount, 'Pending', 'Pending')";
        
        $insert_stmt = $pdo->prepare($insert_sql);
        $insert_stmt->execute([
            ":user_id" => $user_id,
            ":temple_id" => $temple_id,
            ":slot_id" => $slot_id,
            ":num_persons" => $num_persons,
            ":total_amount" => $total_amount
        ]);
        
        $booking_id = $pdo->lastInsertId();
        
        // Reduce capacity
        $pdo->prepare("UPDATE slots SET available_capacity = available_capacity - ? WHERE id = ?")->execute([$num_persons, $slot_id]);
        
        // Redirect to review/payment
        header("location: book.php?review=" . $booking_id);
        exit;
    }
}

// 2. Display Review screen before payment
if (isset($_GET['review'])) {
    $booking_id = intval($_GET['review']);
    $stmt = $pdo->prepare("SELECT b.*, t.name as temple_name, s.slot_date, s.start_time, s.type 
                           FROM bookings b 
                           JOIN temples t ON b.temple_id = t.id 
                           JOIN slots s ON b.slot_id = s.id 
                           WHERE b.id = ? AND b.user_id = ?");
    $stmt->execute([$booking_id, $user_id]);
    $booking = $stmt->fetch();
    
    if (!$booking) {
        die("Invalid booking.");
    }
} else if (empty($error)) {
    header("location: index.php");
    exit;
}

?>

<?php include_once "includes/header.php"; ?>

<div class="form-container" style="max-width: 600px;">
    <?php if (!empty($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
        <a href="javascript:history.back()" class="btn btn-primary">Go Back</a>
    <?php else: ?>
        <h2><i class="fa-solid fa-ticket"></i> Review Your Booking</h2>
        <p style="color: var(--light-text); margin-bottom: 1.5rem;">Please review your details before proceeding to payment.</p>
        
        <div style="background: var(--bg-color); padding: 1.5rem; border-radius: var(--border-radius); margin-bottom: 2rem; border-left: 4px solid var(--primary-color);">
            <h4 style="margin-bottom: 1rem; color: var(--secondary-color);"><?php echo htmlspecialchars($booking['temple_name']); ?></h4>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <p><strong><i class="fa-regular fa-calendar"></i> Date:</strong><br> <?php echo date('d M Y', strtotime($booking['slot_date'])); ?></p>
                <p><strong><i class="fa-regular fa-clock"></i> Time:</strong><br> <?php echo date('h:i A', strtotime($booking['start_time'])); ?></p>
                <p><strong>Type:</strong><br> <?php echo htmlspecialchars($booking['type']); ?></p>
                <p><strong>Persons:</strong><br> <?php echo htmlspecialchars($booking['num_persons']); ?></p>
            </div>
            
            <div style="margin-top: 1.5rem; padding-top: 1rem; border-top: 1px solid #ddd; font-size: 1.2rem; font-weight: bold; text-align: right; color: var(--success);">
                Total Amount: ₹<?php echo $booking['total_amount']; ?>
            </div>
        </div>

        <div style="display: flex; gap: 1rem;">
            <a href="payment.php?booking_id=<?php echo $booking_id; ?>" class="btn btn-primary btn-block"><i class="fa-solid fa-credit-card"></i> Proceed to Payment</a>
        </div>
    <?php endif; ?>
</div>

<?php include_once "includes/footer.php"; ?>

