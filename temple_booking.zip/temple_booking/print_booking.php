<?php
require_once "includes/config.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    echo "Unauthorized access.";
    exit;
}

if (!isset($_GET['booking_id'])) {
    echo "No booking ID provided.";
    exit;
}

$booking_id = trim($_GET['booking_id']);
$user_id = $_SESSION["id"];

$sql = "SELECT b.*, t.name as temple_name, t.location, s.slot_date, s.start_time, s.end_time, s.type as slot_type, p.transaction_id, p.payment_method 
        FROM bookings b 
        JOIN temples t ON b.temple_id = t.id 
        JOIN slots s ON b.slot_id = s.id 
        LEFT JOIN payments p ON b.id = p.booking_id 
        WHERE b.id = :booking_id AND b.user_id = :user_id";
        
$stmt = $pdo->prepare($sql);
$stmt->bindParam(":booking_id", $booking_id, PDO::PARAM_INT);
$stmt->bindParam(":user_id", $user_id, PDO::PARAM_INT);
$stmt->execute();
$booking = $stmt->fetch();

if (!$booking) {
    die("Booking not found.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Print Booking Status - #<?php echo str_pad($booking['id'], 6, '0', STR_PAD_LEFT); ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body { background: white; padding: 20px; font-family: Arial, sans-serif; color: black; }
        .receipt { max-width: 600px; margin: 0 auto; border: 2px solid #333; padding: 20px; border-radius: 8px; }
        .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; }
        .header h1 { margin: 0; color: #333; font-size: 24px; }
        .row { display: flex; justify-content: space-between; margin-bottom: 10px; }
        .label { font-weight: bold; color: #555; }
        @media print {
            .no-print { display: none; }
            body { padding: 0; }
            .receipt { border: none; }
        }
    </style>
</head>
<body onload="window.print()">

<div class="receipt">
    <div class="header">
        <h1>DivineDarshan Temple Booking</h1>
        <p>Booking Status / Receipt</p>
    </div>
    
    <div class="row">
        <span class="label">Booking ID:</span>
        <span>#<?php echo str_pad($booking['id'], 6, '0', STR_PAD_LEFT); ?></span>
    </div>
    <div class="row">
        <span class="label">Status:</span>
        <span style="font-weight:bold;"><?php echo htmlspecialchars($booking['status']); ?></span>
    </div>
    <div class="row">
        <span class="label">Temple:</span>
        <span><?php echo htmlspecialchars($booking['temple_name']); ?></span>
    </div>
    <div class="row">
        <span class="label">Location:</span>
        <span><?php echo htmlspecialchars($booking['location']); ?></span>
    </div>
    <hr>
    <div class="row">
        <span class="label">Date:</span>
        <span><?php echo date('d M Y', strtotime($booking['slot_date'])); ?></span>
    </div>
    <div class="row">
        <span class="label">Time:</span>
        <span><?php echo date('h:i A', strtotime($booking['start_time'])); ?></span>
    </div>
    <div class="row">
        <span class="label">Type:</span>
        <span><?php echo htmlspecialchars($booking['slot_type']); ?></span>
    </div>
    <div class="row">
        <span class="label">Number of Persons:</span>
        <span><?php echo htmlspecialchars($booking['num_persons']); ?></span>
    </div>
    <hr>
    <div class="row">
        <span class="label">Amount Paid:</span>
        <span>Rs. <?php echo htmlspecialchars($booking['total_amount']); ?></span>
    </div>
    <?php if ($booking['payment_status'] == 'Completed'): ?>
    <div class="row">
        <span class="label">Payment Method:</span>
        <span><?php echo htmlspecialchars($booking['payment_method']); ?></span>
    </div>
    <div class="row">
        <span class="label">Transaction ID:</span>
        <span><?php echo htmlspecialchars($booking['transaction_id']); ?></span>
    </div>
    <?php else: ?>
    <div class="row">
        <span class="label">Payment Status:</span>
        <span>Pending</span>
    </div>
    <?php endif; ?>
    
    <div style="text-align: center; margin-top: 30px; font-size: 12px; color: #777;">
        <p>Please present this receipt at the temple entrance.</p>
        <p>Printed on <?php echo date('Y-m-d H:i:s'); ?></p>
    </div>
    
    <div class="no-print" style="text-align: center; margin-top: 20px;">
        <button onclick="window.print()" style="padding: 10px 20px; font-size: 16px; cursor: pointer;">Print Again</button>
        <button onclick="window.close()" style="padding: 10px 20px; font-size: 16px; cursor: pointer; margin-left: 10px;">Close Window</button>
    </div>
</div>

</body>
</html>
