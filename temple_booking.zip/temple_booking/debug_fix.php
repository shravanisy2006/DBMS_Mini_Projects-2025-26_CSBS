<?php
require_once "includes/config.php";
echo "<pre style='font-family: monospace; font-size: 16px; background: #000; color: #0f0; padding: 20px; border-radius: 10px;'>";
echo "=== DATABASE AUTHENTICATION REPAIR TOOL ===\n\n";

// Fetch all users
$stmt = $pdo->query("SELECT id, name, email, password, role FROM users");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($users)) {
    echo "ERROR: Users table is completely EMPTY! The database was not imported correctly.\n";
} else {
    echo "Successfully connected to users table.\n";
    echo "Total registered users: " . count($users) . "\n\n";
}

$email = "admin@templesystem.com";
$password = "admin123";

// Determine if admin exists
$sql = "SELECT * FROM users WHERE email = :email";
$stmt = $pdo->prepare($sql);
$stmt->execute(['email' => $email]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$admin) {
    echo "ERROR: The admin account ($email) does NOT exist in your database.\n";
    echo "ACTION: Attempting to create the admin account automatically...\n";
    
    $new_hash = password_hash($password, PASSWORD_DEFAULT);
    $insert = "INSERT INTO users (name, email, password, phone, role) VALUES ('Admin', 'admin@templesystem.com', '$new_hash', '1234567890', 'admin')";
    
    try {
        $pdo->exec($insert);
        echo "SUCCESS! Admin account automatically generated. You can login now.\n";
    } catch (PDOException $e) {
        echo "FAILED: " . $e->getMessage() . "\n";
    }
} else {
    echo "STATUS: Admin account was found!\n";
    echo "Stored Password Hash: " . $admin['password'] . "\n\n";
    
    $hashed_password = $admin['password'];
    
    if (password_verify($password, $hashed_password) || $password === $hashed_password) {
        echo "STATUS: The login logic sees the password as MATCHING!\n";
        echo "If login.php is failing, there is a typo in login.php or your server did not update the files.\n";
        
        if ($password === $hashed_password) {
            echo "ACTION: The password is plain-text. I am auto-upgrading it to a secure hash now...\n";
            $new_hash = password_hash($password, PASSWORD_DEFAULT);
            $update_stmt = $pdo->prepare("UPDATE users SET password = :hash WHERE id = :id");
            $update_stmt->execute(['hash' => $new_hash, 'id' => $admin['id']]);
            echo "SUCCESS It is now securely hashed. You can login.\n";
        }
    } else {
        echo "ERROR: The stored password does NOT match 'admin123'. Someone changed it or it was corrupted.\n";
        echo "ACTION: Forcing password reset to 'admin123'...\n";
        
        $new_hash = password_hash($password, PASSWORD_DEFAULT);
        $update_stmt = $pdo->prepare("UPDATE users SET password = :hash WHERE id = :id");
        $update_stmt->execute(['hash' => $new_hash, 'id' => $admin['id']]);
        
        echo "SUCCESS! The password has been successfully reset! You can login now with admin123.\n";
    }
}
echo "</pre>";
?>
