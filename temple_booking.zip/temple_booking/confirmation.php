<?php
require_once "includes/config.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: auth/login.php");
    exit;
}

if (!isset($_GET['booking_id'])) {
    header("location: index.php");
    exit;
}

$booking_id = trim($_GET['booking_id']);
$user_id = $_SESSION["id"];

$sql = "SELECT b.*, t.name as temple_name, t.location, s.slot_date, s.start_time, s.end_time, s.type as slot_type, p.transaction_id, p.payment_method 
        FROM bookings b 
        JOIN temples t ON b.temple_id = t.id 
        JOIN slots s ON b.slot_id = s.id 
        LEFT JOIN payments p ON b.id = p.booking_id 
        WHERE b.id = :booking_id AND b.user_id = :user_id";
        
$stmt = $pdo->prepare($sql);
$stmt->bindParam(":booking_id", $booking_id, PDO::PARAM_INT);
$stmt->bindParam(":user_id", $user_id, PDO::PARAM_INT);
$stmt->execute();
$booking = $stmt->fetch();

if (!$booking) {
    die("Booking not found.");
}
?>

<?php include_once "includes/header.php"; ?>

<div class="form-container success-popup" style="max-width: 600px; text-align: center;">
    <i class="fa-solid fa-circle-check success-icon"></i>
    <h2 style="color: var(--success); margin-bottom: 0.5rem;">Booking Confirmed!</h2>
    <p style="color: var(--light-text); margin-bottom: 2rem;">Your Darshan/Pooja has been successfully booked.</p>
    
    <div style="text-align: left; background: var(--bg-color); padding: 1.5rem; border-radius: var(--border-radius); border: 1px solid #eee;">
        <div style="display: flex; justify-content: space-between; border-bottom: 1px solid #ddd; padding-bottom: 1rem; margin-bottom: 1rem;">
            <span><strong>Booking ID:</strong> #<?php echo str_pad($booking['id'], 6, '0', STR_PAD_LEFT); ?></span>
            <span class="badge badge-confirmed">Confirmed</span>
        </div>
        
        <h4 style="color: var(--secondary-color); margin-bottom: 0.5rem;"><?php echo htmlspecialchars($booking['temple_name']); ?></h4>
        <p style="font-size: 0.9rem; color: var(--light-text); margin-bottom: 1rem;"><i class="fa-solid fa-location-dot"></i> <?php echo htmlspecialchars($booking['location']); ?></p>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
            <div>
                <p style="font-size: 0.9rem; color: var(--light-text);">Type</p>
                <p style="font-weight: bold;"><?php echo htmlspecialchars($booking['slot_type']); ?></p>
            </div>
            <div>
                <p style="font-size: 0.9rem; color: var(--light-text);">Persons</p>
                <p style="font-weight: bold;"><?php echo htmlspecialchars($booking['num_persons']); ?></p>
            </div>
            <div>
                <p style="font-size: 0.9rem; color: var(--light-text);">Date</p>
                <p style="font-weight: bold;"><?php echo date('d M Y', strtotime($booking['slot_date'])); ?></p>
            </div>
            <div>
                <p style="font-size: 0.9rem; color: var(--light-text);">Time</p>
                <p style="font-weight: bold;"><?php echo date('h:i A', strtotime($booking['start_time'])); ?></p>
            </div>
        </div>
        
        <div style="background: white; padding: 1rem; border-radius: 4px; border: 1px solid #eee;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                <span style="color: var(--light-text);">Amount Paid:</span>
                <span style="font-weight: bold;">₹<?php echo htmlspecialchars($booking['total_amount']); ?></span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                <span style="color: var(--light-text);">Payment Method:</span>
                <span style="font-weight: bold;"><?php echo htmlspecialchars($booking['payment_method']); ?></span>
            </div>
            <div style="display: flex; justify-content: space-between;">
                <span style="color: var(--light-text);">Transaction ID:</span>
                <span style="font-weight: bold; font-family: monospace;"><?php echo htmlspecialchars($booking['transaction_id']); ?></span>
            </div>
        </div>
    </div>
    
    <div style="margin-top: 2rem; display: flex; gap: 1rem; justify-content: center;">
        <button onclick="window.print()" class="btn btn-outline"><i class="fa-solid fa-print"></i> Print Receipt</button>
        <a href="my_bookings.php" class="btn btn-primary">Go to My Bookings</a>
    </div>
</div>

<?php include_once "includes/footer.php"; ?>
