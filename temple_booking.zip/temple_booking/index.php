<?php
require_once "includes/config.php";

$search_query = "";
$query_param = "";

if (isset($_GET['search'])) {
    $search_query = trim($_GET['search']);
    $query_param = "%" . $search_query . "%";
    $sql = "SELECT * FROM temples WHERE name LIKE :search OR location LIKE :search ORDER BY created_at DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(":search", $query_param, PDO::PARAM_STR);
} else {
    $sql = "SELECT * FROM temples ORDER BY created_at DESC";
    $stmt = $pdo->prepare($sql);
}

$stmt->execute();
$temples = $stmt->fetchAll();
?>

<?php include_once "includes/header.php"; ?>

<div class="slider-container">
    <div class="slide active" style="background-image: url('assets/images/kashi_vishwanath.jpg');">
        <div class="slide-content">
            <h1>Experience the Divine</h1>
            <p>Book your Darshan and Pooja slots online effortlessly with our secure and real-time booking system.</p>
        </div>
    </div>
    <div class="slide" style="background-image: url('assets/images/tirupati_balaji.jpg');">
        <div class="slide-content">
            <h1>Spiritual Journey Awaits</h1>
            <p>Connect with the divine presence at the most revered temples across the country.</p>
        </div>
    </div>
    <div class="slide" style="background-image: url('assets/images/meenakshi_amman.jpg');">
        <div class="slide-content">
            <h1>Seamless Booking Experience</h1>
            <p>No more long queues. Select your flexible date and time from the comfort of your home.</p>
        </div>
    </div>
</div>

<div class="search-bar fade-in">
    <form action="index.php" method="GET" style="display:flex; width:100%;">
        <div class="form-group" style="margin-bottom:0; flex:1;">
            <input type="text" name="search" id="search" class="form-control" placeholder=" " value="<?php echo htmlspecialchars($search_query); ?>" style="border-radius: 30px 0 0 30px;">
            <label for="search">Search for temples or locations...</label>
        </div>
        <button type="submit" class="btn btn-primary" style="border-radius: 0 30px 30px 0;"><i class="fa-solid fa-search"></i></button>
    </form>
</div>

<h2 style="text-align:center; margin-bottom: 2rem;" class="fade-in">Featured Temples</h2>

<div class="grid">
    <?php if (count($temples) > 0): ?>
        <?php foreach ($temples as $temple): ?>
            <div class="card fade-in">
                <div class="card-img-wrapper">
                    <?php 
                    $img_src = !empty($temple['image_url']) ? $temple['image_url'] : 'assets/images/default_temple.jpg'; 
                    ?>
                    <img src="<?php echo htmlspecialchars($img_src); ?>" alt="<?php echo htmlspecialchars($temple['name']); ?>" class="card-img" onerror="this.src='https://via.placeholder.com/400x200?text=Temple+Image';">
                </div>
                <div class="card-body">
                    <h3 class="card-title"><?php echo htmlspecialchars($temple['name']); ?></h3>
                    <p style="font-size: 0.9rem; color: var(--primary-dark); margin-bottom: 0.5rem;">
                        <i class="fa-solid fa-location-dot"></i> <?php echo htmlspecialchars($temple['location']); ?>
                    </p>
                    <p class="card-text"><?php echo htmlspecialchars(substr($temple['description'], 0, 100)) . '...'; ?></p>
                    <a href="temple.php?id=<?php echo $temple['id']; ?>" class="btn btn-outline btn-block" style="justify-content:center;">View Details & Book</a>
                </div>
            </div>

        <?php endforeach; ?>
    <?php else: ?>
        <p style="text-align:center; grid-column: 1 / -1;">No temples found matching your search.</p>
    <?php endif; ?>
</div>

<?php include_once "includes/footer.php"; ?>
