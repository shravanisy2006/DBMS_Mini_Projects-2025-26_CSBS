-- phpMyAdmin SQL Dump
-- Database: `temple_db`

CREATE DATABASE IF NOT EXISTS `temple_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `temple_db`;

--
-- Table structure for table `users`
--
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL UNIQUE,
  `password` varchar(255) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `role` enum('user','admin') DEFAULT 'user',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping default admin user (password: admin123)
INSERT INTO `users` (`name`, `email`, `password`, `role`) VALUES
('Admin', 'admin@templesystem.com', '$2y$10$wS2CkV/Z9Yf/Q6P6nZ85AOlH9vK5E1o3vE2Y9Vj7E3kC4Z.R7bL4i', 'admin');

--
-- Table structure for table `temples`
--
CREATE TABLE `temples` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `description` text NOT NULL,
  `location` varchar(150) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Inserting sample temples
INSERT INTO `temples` (`name`, `description`, `location`, `image_url`) VALUES
('Sri Kashi Vishwanath Temple', 'One of the most famous Hindu temples dedicated to Lord Shiva. It is located in Varanasi, Uttar Pradesh, India.', 'Varanasi, UP', 'assets/images/kashi_vishwanath.jpg'),
('Tirupati Balaji Temple', 'A landmark Vaishnavite temple situated in the hill town of Tirumala at Tirupati in Chittoor district of Andhra Pradesh, India.', 'Tirupati, AP', 'assets/images/tirupati_balaji.jpg'),
('Meenakshi Amman Temple', 'A historic Hindu temple located on the southern bank of the Vaigai River in the temple city of Madurai, Tamil Nadu.', 'Madurai, TN', 'assets/images/meenakshi_amman.jpg');

--
-- Table structure for table `slots`
--
CREATE TABLE `slots` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `temple_id` int(11) NOT NULL,
  `slot_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `total_capacity` int(11) NOT NULL DEFAULT 50,
  `available_capacity` int(11) NOT NULL DEFAULT 50,
  `type` enum('Darshan','Pooja') NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`temple_id`) REFERENCES `temples`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert some dummy slots
INSERT INTO `slots` (`temple_id`, `slot_date`, `start_time`, `end_time`, `total_capacity`, `available_capacity`, `type`, `price`) VALUES
(1, CURDATE(), '08:00:00', '10:00:00', 100, 100, 'Darshan', 0.00),
(1, CURDATE(), '10:00:00', '12:00:00', 30, 30, 'Pooja', 501.00),
(2, CURDATE() + INTERVAL 1 DAY, '06:00:00', '09:00:00', 200, 200, 'Darshan', 100.00),
(2, CURDATE() + INTERVAL 1 DAY, '11:00:00', '13:00:00', 50, 50, 'Pooja', 1001.00),
(3, CURDATE() + INTERVAL 2 DAY, '07:00:00', '10:00:00', 150, 150, 'Darshan', 0.00);

--
-- Table structure for table `bookings`
--
CREATE TABLE `bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `temple_id` int(11) NOT NULL,
  `slot_id` int(11) NOT NULL,
  `booking_date` timestamp DEFAULT CURRENT_TIMESTAMP,
  `num_persons` int(11) NOT NULL DEFAULT 1,
  `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('Pending','Confirmed','Cancelled') DEFAULT 'Pending',
  `payment_status` enum('Pending','Completed') DEFAULT 'Pending',
  PRIMARY KEY (`id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`),
  FOREIGN KEY (`temple_id`) REFERENCES `temples`(`id`),
  FOREIGN KEY (`slot_id`) REFERENCES `slots`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Table structure for table `payments`
--
CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `booking_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` enum('UPI','Card','Net Banking') NOT NULL,
  `transaction_id` varchar(100) NOT NULL UNIQUE,
  `payment_date` timestamp DEFAULT CURRENT_TIMESTAMP,
  `status` enum('Success','Failed') DEFAULT 'Success',
  PRIMARY KEY (`id`),
  FOREIGN KEY (`booking_id`) REFERENCES `bookings`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
