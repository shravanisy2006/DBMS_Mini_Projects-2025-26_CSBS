<?php
require_once "includes/config.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: auth/login.php");
    exit;
}

$user_id = $_SESSION["id"];

$sql = "SELECT b.*, t.name as temple_name, s.slot_date, s.start_time, s.type as slot_type 
        FROM bookings b 
        JOIN temples t ON b.temple_id = t.id 
        JOIN slots s ON b.slot_id = s.id 
        WHERE b.user_id = :user_id 
        ORDER BY b.booking_date DESC";
        
$stmt = $pdo->prepare($sql);
$stmt->bindParam(":user_id", $user_id, PDO::PARAM_INT);
$stmt->execute();
$bookings = $stmt->fetchAll();
?>

<?php include_once "includes/header.php"; ?>

<h2><i class="fa-solid fa-list-check"></i> My Bookings</h2>
<p style="color: var(--light-text); margin-bottom: 2rem;">Manage and view your temple darshan and pooja reservations.</p>

<?php if (isset($_GET['cancelled'])): ?>
    <div class="alert alert-success">Booking has been successfully cancelled.</div>
<?php endif; ?>

<div class="table-responsive">
    <table>
        <thead>
            <tr>
                <th>Booking ID</th>
                <th>Temple</th>
                <th>Type</th>
                <th>Date & Time</th>
                <th>Persons</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($bookings) > 0): ?>
                <?php foreach ($bookings as $booking): ?>
                    <tr>
                        <td><strong>#<?php echo str_pad($booking['id'], 6, '0', STR_PAD_LEFT); ?></strong></td>
                        <td><?php echo htmlspecialchars($booking['temple_name']); ?></td>
                        <td>
                            <span class="badge <?php echo strtolower($booking['slot_type']) == 'darshan' ? 'badge-darshan' : 'badge-pooja'; ?>">
                                <?php echo htmlspecialchars($booking['slot_type']); ?>
                            </span>
                        </td>
                        <td>
                            <?php echo date('d M Y', strtotime($booking['slot_date'])); ?><br>
                            <small style="color: var(--light-text);"><?php echo date('h:i A', strtotime($booking['start_time'])); ?></small>
                        </td>
                        <td><?php echo htmlspecialchars($booking['num_persons']); ?></td>
                        <td>₹<?php echo htmlspecialchars($booking['total_amount']); ?></td>
                        <td>
                            <?php 
                                $status_class = 'badge-pending';
                                if ($booking['status'] == 'Confirmed') $status_class = 'badge-confirmed';
                                if ($booking['status'] == 'Cancelled') $status_class = 'badge-cancelled';
                            ?>
                            <span class="badge <?php echo $status_class; ?>"><?php echo htmlspecialchars($booking['status']); ?></span>
                        </td>
                        <td>
                            <a href="confirmation.php?booking_id=<?php echo $booking['id']; ?>" class="btn btn-outline" style="padding: 0.3rem 0.6rem; font-size: 0.8rem;" title="View"><i class="fa-solid fa-eye"></i></a>
                            <a href="print_booking.php?booking_id=<?php echo $booking['id']; ?>" class="btn btn-primary" style="padding: 0.3rem 0.6rem; font-size: 0.8rem;" target="_blank" title="Print Status"><i class="fa-solid fa-print"></i></a>
                            <?php if ($booking['status'] != 'Cancelled' && strtotime($booking['slot_date']) >= strtotime('today')): ?>
                                <a href="cancel_booking.php?id=<?php echo $booking['id']; ?>" class="btn btn-danger" style="padding: 0.3rem 0.6rem; font-size: 0.8rem;" onclick="return confirm('Are you sure you want to cancel this booking?');" title="Cancel"><i class="fa-solid fa-xmark"></i></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="8" style="text-align: center;">You have no bookings yet. <a href="index.php" style="color: var(--primary-dark); font-weight: bold;">Book now</a></td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include_once "includes/footer.php"; ?>
