<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
    header("location: ../index.php");
    exit;
}

require_once "../includes/config.php";

$email = $password = "";
$email_err = $password_err = $login_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter email.";
    } else {
        $email = trim($_POST["email"]);
    }
    
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter your password.";
    } else {
        $password = trim($_POST["password"]);
    }
    
    if (empty($email_err) && empty($password_err)) {
        $sql = "SELECT id, name, email, password, role FROM users WHERE email = :email";
        
        if ($stmt = $pdo->prepare($sql)) {
            $stmt->bindParam(":email", $param_email, PDO::PARAM_STR);
            $param_email = trim($_POST["email"]);
            
            if ($stmt->execute()) {
                if ($stmt->rowCount() == 1) {
                    if ($row = $stmt->fetch()) {
                        $id = $row["id"];
                        $name = $row["name"];
                        $email = $row["email"];
                        $hashed_password = $row["password"];
                        $role = $row["role"];
                        
                        if (password_verify($password, $hashed_password) || $password === $hashed_password) {
                            
                            // Immediately fix the plain-text database entry if caught!
                            if ($password === $hashed_password) {
                                $new_hash = password_hash($password, PASSWORD_DEFAULT);
                                $fix_sql = "UPDATE users SET password = :hash WHERE id = :id";
                                $fix_stmt = $pdo->prepare($fix_sql);
                                $fix_stmt->execute(['hash' => $new_hash, 'id' => $id]);
                            }

                            session_start();
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["email"] = $email;
                            $_SESSION["name"] = $name;
                            $_SESSION["role"] = $role;
                            
                            if ($role === 'admin') {
                                header("location: ../admin/index.php");
                            } else {
                                header("location: ../index.php");
                            }
                        } else {
                            $login_err = "Invalid email or password.";
                        }
                    }
                } else {
                    $login_err = "Invalid email or password.";
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
            unset($stmt);
        }
    }
    unset($pdo);
}
?>
<?php include_once "../includes/header.php"; ?>

<div class="form-container">
    <h2><i class="fa-solid fa-right-to-bracket"></i> Login to Account</h2>
    
    <?php 
    if(!empty($login_err)){
        echo '<div class="alert alert-danger">' . $login_err . '</div>';
    }
    if(isset($_GET['registered'])){
        echo '<div class="alert alert-success">Registration successful! Please log in.</div>';
    }
    ?>

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div class="form-floating">
            <input type="email" name="email" id="email" class="form-control" placeholder=" " value="<?php echo $email; ?>">
            <label for="email">Email</label>
            <span class="badge badge-cancelled" style="display: <?php echo empty($email_err) ? 'none' : 'inline-block'; ?>; margin-top:5px; position: relative; z-index: 10;"><?php echo $email_err; ?></span>
        </div>    
        <div class="form-floating">
            <input type="password" name="password" id="password" class="form-control" placeholder=" ">
            <label for="password">Password</label>
            <span class="badge badge-cancelled" style="display: <?php echo empty($password_err) ? 'none' : 'inline-block'; ?>; margin-top:5px; position: relative; z-index: 10;"><?php echo $password_err; ?></span>
        </div>
        <div class="form-group" style="margin-top: 2rem;">
            <button type="submit" class="btn btn-primary btn-block"><i class="fas fa-sign-in-alt"></i> Login</button>
        </div>
        <p style="text-align: center; margin-top: 1rem;">Don't have an account? <a href="register.php" style="color: var(--primary-color); font-weight: 600;">Register now</a>.</p>
        
        <div style="margin-top: 1.5rem; padding: 1rem; background: var(--bg-color); border: 1px solid var(--border-color); border-radius: 8px; font-size: 0.85rem; text-align: center; color: var(--light-text);">
            <strong>Test Admin Account</strong><br>
            Email: <code>admin@templesystem.com</code> <br>
            Password: <code>admin123</code>
        </div>
    </form>
</div>

<?php include_once "../includes/footer.php"; ?>
