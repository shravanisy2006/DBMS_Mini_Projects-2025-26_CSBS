<?php
require_once "../includes/config.php";

$name = $email = $password = $confirm_password = $phone = "";
$name_err = $email_err = $password_err = $confirm_password_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate name
    if (empty(trim($_POST["name"]))) {
        $name_err = "Please enter your full name.";
    } else {
        $name = trim($_POST["name"]);
    }

    // Validate email
    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter your email.";
    } elseif (!filter_var(trim($_POST["email"]), FILTER_VALIDATE_EMAIL)) {
        $email_err = "Invalid email format.";
    } else {
        $sql = "SELECT id FROM users WHERE email = :email";
        if ($stmt = $pdo->prepare($sql)) {
            $stmt->bindParam(":email", $param_email, PDO::PARAM_STR);
            $param_email = trim($_POST["email"]);
            if ($stmt->execute()) {
                if ($stmt->rowCount() == 1) {
                    $email_err = "This email is already registered.";
                } else {
                    $email = trim($_POST["email"]);
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
            unset($stmt);
        }
    }

    // Validate password
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter a password.";
    } elseif (strlen(trim($_POST["password"])) < 6) {
        $password_err = "Password must have at least 6 characters.";
    } else {
        $password = trim($_POST["password"]);
    }

    // Validate confirm password
    if (empty(trim($_POST["confirm_password"]))) {
        $confirm_password_err = "Please confirm password.";
    } else {
        $confirm_password = trim($_POST["confirm_password"]);
        if (empty($password_err) && ($password != $confirm_password)) {
            $confirm_password_err = "Password did not match.";
        }
    }

    $phone = trim($_POST["phone"]);

    if (empty($name_err) && empty($email_err) && empty($password_err) && empty($confirm_password_err)) {
        $sql = "INSERT INTO users (name, email, password, phone, role) VALUES (:name, :email, :password, :phone, 'user')";
        if ($stmt = $pdo->prepare($sql)) {
            $stmt->bindParam(":name", $param_name, PDO::PARAM_STR);
            $stmt->bindParam(":email", $param_email, PDO::PARAM_STR);
            $stmt->bindParam(":password", $param_password, PDO::PARAM_STR);
            $stmt->bindParam(":phone", $param_phone, PDO::PARAM_STR);

            $param_name = $name;
            $param_email = $email;
            $param_password = password_hash($password, PASSWORD_DEFAULT);
            $param_phone = $phone;

            if ($stmt->execute()) {
                header("location: login.php?registered=1");
            } else {
                echo "Something went wrong. Please try again later.";
            }
            unset($stmt);
        }
    }
    unset($pdo);
}
?>
<?php include_once "../includes/header.php"; ?>

<div class="form-container">
    <h2><i class="fa-solid fa-user-plus"></i> User Registration</h2>
    <p style="text-align: center; margin-bottom: 1.5rem;">Join us to book your Darshan quickly.</p>

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div class="form-floating">
            <input type="text" name="name" id="name" class="form-control" placeholder=" " value="<?php echo $name; ?>">
            <label for="name">Full Name</label>
            <span class="badge badge-cancelled" style="display: <?php echo empty($name_err) ? 'none' : 'inline-block'; ?>; margin-top:5px; position:relative; z-index:10;"><?php echo $name_err; ?></span>
        </div>    
        <div class="form-floating">
            <input type="email" name="email" id="email" class="form-control" placeholder=" " value="<?php echo $email; ?>">
            <label for="email">Email Address</label>
            <span class="badge badge-cancelled" style="display: <?php echo empty($email_err) ? 'none' : 'inline-block'; ?>; margin-top:5px; position:relative; z-index:10;"><?php echo $email_err; ?></span>
        </div>
        <div class="form-floating">
            <input type="text" name="phone" id="phone" class="form-control" placeholder=" " value="<?php echo $phone; ?>">
            <label for="phone">Phone Number</label>
        </div>
        <div class="form-floating">
            <input type="password" name="password" id="password" class="form-control" placeholder=" ">
            <label for="password">Password</label>
            <span class="badge badge-cancelled" style="display: <?php echo empty($password_err) ? 'none' : 'inline-block'; ?>; margin-top:5px; position:relative; z-index:10;"><?php echo $password_err; ?></span>
        </div>
        <div class="form-floating">
            <input type="password" name="confirm_password" id="confirm_password" class="form-control" placeholder=" ">
            <label for="confirm_password">Confirm Password</label>
            <span class="badge badge-cancelled" style="display: <?php echo empty($confirm_password_err) ? 'none' : 'inline-block'; ?>; margin-top:5px; position:relative; z-index:10;"><?php echo $confirm_password_err; ?></span>
        </div>
        <div class="form-group" style="margin-top:2rem;">
            <button type="submit" class="btn btn-primary btn-block"><i class="fas fa-user-plus"></i> Register Now</button>
        </div>
        <p style="text-align: center; margin-top: 1rem;">Already have an account? <a href="login.php" style="color: var(--primary-color); font-weight: 600;">Login here</a>.</p>
    </form>
</div>

<?php include_once "../includes/footer.php"; ?>
