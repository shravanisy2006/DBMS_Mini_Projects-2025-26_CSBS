<?php
// A small utility to find the local MySQL root password
$passwords_to_try = [
    '', 
    'root', 
    'admin', 
    'password', 
    '1234', 
    '12345', 
    '123456', 
    'mysql', 
    'xampp',
    'qwerty'
];

$found = false;
$correct_password = "";

echo "<div style='font-family: Arial, sans-serif; padding: 20px;'>";
echo "<h2>MySQL Password Recovery Tool</h2><ul>";

foreach ($passwords_to_try as $p) {
    try {
        // Suppress warnings specifically for the connection attempts
        $pdo = @new PDO("mysql:host=localhost", "root", $p);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $correct_password = $p;
        $found = true;
        break;
    } catch(PDOException $e) {
        $display_p = ($p === '') ? '[Empty Password]' : $p;
        echo "<li style='color: #666;'>Tried password: <b>$display_p</b> - Failed</li>";
    }
}

echo "</ul><hr>";

if ($found) {
    $display_p = ($correct_password === '') ? 'EMPTY (Leave it blank!)' : $correct_password;
    echo "<h1 style='color: green;'>✅ SUCCESS! Your MySQL root password is: <br><br> <span style='background: #eee; padding: 10px; border: 2px dashed #333;'>$display_p</span></h1>";
    echo "<h3>What to do next:</h3>";
    echo "<p>1. Go to <a href='http://localhost/phpmyadmin/'>http://localhost/phpmyadmin/</a></p>";
    echo "<p>2. Enter <b>root</b> as the Username.</p>";
    echo "<p>3. Enter the exact password shown above in the Password field.</p>";
    echo "<p>4. Once logged in, remember to update the <b>includes/config.php</b> file in this project with that same password!</p>";
} else {
    echo "<h1 style='color: red;'>❌ Could not find the password using common defaults.</h1>";
    echo "<p>Your database password is something custom. If you cannot remember it at all, you may need to completely reinstall XAMPP.</p>";
}

echo "</div>";
?>
