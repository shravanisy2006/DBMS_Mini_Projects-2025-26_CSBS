# Temple Darshan Booking System

A complete mini project for booking Temple Darshan and Pooja slots, built using HTML, CSS, PHP, and MySQL. It features user registration, dynamic slot availability, dummy payment processing, user booking history, and an Admin dashboard to manage temples, slots, and bookings.

## System Features

1. **User Module**
   - Register and Login logic with password hashing
   - View Temples with search and filtering
   - View dynamic real-time slot availability for Darshan & Pooja
   - Book multiple tickets and process them through a dummy payment gateway
   - View booking history and cancel pending/upcoming bookings

2. **Admin Module**
   - Dashboard with key statistics
   - Add, Edit, Delete temples in the system
   - Generate slots for specific times, dates, and capacities
   - View all system-wide bookings and manually alter statuses (Confirmed, Cancelled)

## Installation & Setup Instructions

1. **Install XAMPP**
   Download and install [XAMPP](https://www.apachefriends.org/index.html) to get Apache and MySQL running locally.

2. **Start the Servers**
   Open the XAMPP Control Panel and start **Apache** and **MySQL**.

3. **Deploy the Codebase**
   Ensure the `temple_booking` folder is placed inside your web server directory (e.g., inside `C:/xampp/htdocs/` for XAMPP). You may need to move it there from its current location.

4. **Database Configuration**
   - Open your browser and go to `http://localhost/phpmyadmin/`.
   - Click on the **Import** tab at the top.
   - Choose the `database.sql` file located inside the `temple_booking` root folder.
   - Click **Go** at the bottom to execute the script.
   *This script automatically creates the `temple_db` database along with all the required tables, sample temples, slots, and an Admin user.*

5. **Run the Project**
   Open your browser and navigate to:
   `http://localhost/temple_booking/`

## Default Admin Credentials
- **Email:** `admin@templesystem.com`
- **Password:** `admin123`

*(Note: You can safely log in using these credentials to access the admin dashboard by clicking the "Admin Panel" link after login).*

## Project Structure
```text
temple_booking/
├── admin/
│   ├── index.php             (Admin Dashboard)
│   ├── manage_temples.php    (Add/Delete Temples)
│   ├── manage_slots.php      (Manage Darshan/Pooja slots)
│   └── manage_bookings.php   (View & Update Booking statuses)
├── assets/
│   ├── css/
│   │   └── style.css         (Modern global stylesheet)
│   └── images/               (Contains system images & AI generations)
├── auth/
│   ├── register.php
│   ├── login.php
│   └── logout.php
├── includes/
│   ├── config.php            (Database Connection via PDO)
│   ├── header.php            (Global Navigation & UI wrappers)
│   └── footer.php            (Global Footer)
├── index.php                 (Home - Temple List & Search)
├── temple.php                (Temple Details & Slot Viewer)
├── book.php                  (Cart/Checkout logic & Person select)
├── payment.php               (Dummy Payment Gateway simulator)
├── confirmation.php          (Booking Receipt view)
├── my_bookings.php           (User Dashboard history)
├── cancel_booking.php        (User Action to cancel and free up capacity)
└── database.sql              (MySQL schema and seed data)
```
