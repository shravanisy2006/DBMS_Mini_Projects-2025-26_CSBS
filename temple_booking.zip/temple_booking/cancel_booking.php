<?php
require_once "includes/config.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: auth/login.php");
    exit;
}

if (isset($_GET['id'])) {
    $booking_id = intval($_GET['id']);
    $user_id = $_SESSION["id"];
    
    // Check if booking belongs to user & is valid for cancellation
    $sql = "SELECT * FROM bookings WHERE id = :id AND user_id = :user_id AND status != 'Cancelled'";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(":id", $booking_id, PDO::PARAM_INT);
    $stmt->bindParam(":user_id", $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $booking = $stmt->fetch();
    
    if ($booking) {
        $pdo->beginTransaction();
        try {
            // Update booking status
            $up_sql = "UPDATE bookings SET status = 'Cancelled' WHERE id = :id";
            $up_stmt = $pdo->prepare($up_sql);
            $up_stmt->bindParam(":id", $booking_id, PDO::PARAM_INT);
            $up_stmt->execute();
            
            // Restore capacity
            $slot_sql = "UPDATE slots SET available_capacity = available_capacity + :num WHERE id = :slot_id";
            $slot_stmt = $pdo->prepare($slot_sql);
            $slot_stmt->bindParam(":num", $booking['num_persons'], PDO::PARAM_INT);
            $slot_stmt->bindParam(":slot_id", $booking['slot_id'], PDO::PARAM_INT);
            $slot_stmt->execute();
            
            $pdo->commit();
            header("location: my_bookings.php?cancelled=1");
            exit;
        } catch (Exception $e) {
            $pdo->rollBack();
            die("Error cancelling booking.");
        }
    }
}

header("location: my_bookings.php");
exit;
?>
