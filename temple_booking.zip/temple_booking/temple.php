<?php
require_once "includes/config.php";

if (!isset($_GET['id']) || empty(trim($_GET['id']))) {
    header("location: index.php");
    exit;
}

$temple_id = trim($_GET['id']);

// Fetch temple details
$sql = "SELECT * FROM temples WHERE id = :id";
if ($stmt = $pdo->prepare($sql)) {
    $stmt->bindParam(":id", $temple_id, PDO::PARAM_INT);
    if ($stmt->execute()) {
        if ($stmt->rowCount() == 1) {
            $temple = $stmt->fetch();
        } else {
            header("location: index.php");
            exit;
        }
    } else {
        echo "Oops! Something went wrong.";
    }
}

// Fetch available slots
$slots_sql = "SELECT * FROM slots WHERE temple_id = :temple_id AND slot_date >= CURDATE() AND available_capacity > 0 ORDER BY slot_date ASC, start_time ASC";
$slots_stmt = $pdo->prepare($slots_sql);
$slots_stmt->bindParam(":temple_id", $temple_id, PDO::PARAM_INT);
$slots_stmt->execute();
$slots = $slots_stmt->fetchAll();
?>

<?php include_once "includes/header.php"; ?>

<div style="background: var(--white); border-radius: var(--border-radius); overflow: hidden; box-shadow: var(--box-shadow); margin-bottom: 3rem;">
    <?php $img_src = !empty($temple['image_url']) ? $temple['image_url'] : 'https://via.placeholder.com/1200x400?text=Temple+Cover'; ?>
    <div style="height: 350px; background: url('<?php echo htmlspecialchars($img_src); ?>') center/cover no-repeat; position: relative;">
        <div style="position: absolute; bottom:0; left:0; right:0; background: linear-gradient(transparent, rgba(0,0,0,0.8)); padding: 2rem; color: white;">
            <h1 style="color:var(--primary-color); text-shadow: 1px 1px 3px rgba(0,0,0,0.5); font-size: 2.5rem;"><?php echo htmlspecialchars($temple['name']); ?></h1>
            <p style="font-size: 1.2rem;"><i class="fa-solid fa-location-dot"></i> <?php echo htmlspecialchars($temple['location']); ?></p>
        </div>
    </div>
    <div style="padding: 2rem;">
        <h3 style="margin-bottom: 1rem; color: var(--secondary-color);">About the Temple</h3>
        <p style="color: var(--light-text); font-size: 1.1rem; line-height: 1.8;"><?php echo nl2br(htmlspecialchars($temple['description'])); ?></p>
    </div>
</div>

<h2 style="color: var(--secondary-color); margin-bottom: 1.5rem;"><i class="fa-regular fa-calendar-check"></i> Book Darshan & Pooja Online</h2>

<div class="form-container" style="max-width: 800px; margin: 0 auto; background: var(--white); padding: 2rem; border-radius: var(--border-radius); box-shadow: var(--box-shadow); border-top: 4px solid var(--primary-color);">
    <form action="book.php" method="post">
        <input type="hidden" name="temple_id" value="<?php echo $temple['id']; ?>">
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
            <div class="form-group">
                <label><i class="fa-regular fa-calendar"></i> Select Date</label>
                <input type="date" name="booking_date" class="form-control" min="<?php echo date('Y-m-d'); ?>" required>
            </div>
            
            <div class="form-group">
                <label><i class="fa-regular fa-clock"></i> Select Time</label>
                <input type="time" name="booking_time" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label>Booking Type</label>
                <select name="booking_type" class="form-control" required>
                    <option value="Darshan">General Darshan (Free)</option>
                    <option value="Pooja">Special Pooja (₹501 per person)</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>Number of Persons</label>
                <input type="number" name="num_persons" class="form-control" value="1" min="1" max="15" required>
            </div>
        </div>
        
        <div class="form-group" style="margin-top: 1.5rem; text-align: center;">
            <button type="submit" name="flexible_book" class="btn btn-primary btn-block" style="font-size: 1.1rem; padding: 0.8rem;"><i class="fa-solid fa-check-circle"></i> Proceed to Booking</button>
        </div>
    </form>
</div>

<?php include_once "includes/footer.php"; ?>
