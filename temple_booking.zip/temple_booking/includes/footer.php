    </main>
    <footer>
        <div class="footer-content">
            <h3><i class="fa-solid fa-om"></i> DivineDarshan</h3>
            <p>&copy; <?php echo date("Y"); ?> Temple Darshan Booking System. All Rights Reserved.</p>
        </div>
    </footer>
    
    <!-- Use base path dynamically for Javascript -->
    <?php $base_js_url = isset($base_url) ? $base_url : '/temple_booking'; ?>
    <script src="<?php echo $base_js_url; ?>/assets/js/main.js"></script>
    
</body>
</html>
