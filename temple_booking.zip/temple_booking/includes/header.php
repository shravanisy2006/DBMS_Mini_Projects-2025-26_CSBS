<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Temple Darshan Booking System</title>
    <!-- Use base path dynamically -->
    <?php $base_url = '/temple_booking'; ?>
    <link rel="stylesheet" href="<?php echo $base_url; ?>/assets/css/style.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="spinner"></div>
    </div>
    
    <header>
        <nav class="navbar">
            <a href="<?php echo $base_url; ?>/index.php" class="logo">
                <i class="fa-solid fa-om"></i> DivineDarshan
            </a>
            <ul class="nav-links">
                <li><a href="<?php echo $base_url; ?>/index.php">Home</a></li>
                <?php if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true): ?>
                    <li><a href="<?php echo $base_url; ?>/my_bookings.php">My Bookings</a></li>
                    <?php if (isset($_SESSION["role"]) && $_SESSION["role"] === 'admin'): ?>
                        <li><a href="<?php echo $base_url; ?>/admin/index.php">Admin Panel</a></li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>
            <div class="nav-buttons">
                <!-- Dark Mode Toggle -->
                <button id="darkModeToggle"><i class="fas fa-moon"></i></button>

                <?php if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true): ?>
                    <span style="font-weight:600; margin-right: 15px; color: var(--primary-dark);">
                        Hi, <?php echo htmlspecialchars($_SESSION["name"]); ?>
                        <?php if (isset($_SESSION["role"]) && $_SESSION["role"] === 'admin'): ?>
                            <span class="badge badge-admin" style="font-size: 0.7rem; margin-left: 5px;">Admin</span>
                        <?php endif; ?>
                    </span>
                    <a href="<?php echo $base_url; ?>/auth/logout.php" class="btn btn-outline">Logout</a>
                <?php else: ?>
                    <a href="<?php echo $base_url; ?>/auth/login.php" class="btn btn-outline">Login</a>
                    <a href="<?php echo $base_url; ?>/auth/register.php" class="btn btn-primary">Register</a>
                <?php endif; ?>
            </div>
        </nav>
    </header>
    <main>

