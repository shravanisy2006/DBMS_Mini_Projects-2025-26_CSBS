<?php
require_once "includes/config.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: auth/login.php");
    exit;
}

if (!isset($_GET['booking_id']) && !isset($_POST['booking_id'])) {
    header("location: index.php");
    exit;
}

$booking_id = isset($_GET['booking_id']) ? trim($_GET['booking_id']) : trim($_POST['booking_id']);
$user_id = $_SESSION["id"];

// Verify booking belongs to user
$sql = "SELECT b.*, t.name as temple_name 
        FROM bookings b 
        JOIN temples t ON b.temple_id = t.id 
        WHERE b.id = :booking_id AND b.user_id = :user_id AND b.payment_status = 'Pending'";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(":booking_id", $booking_id, PDO::PARAM_INT);
$stmt->bindParam(":user_id", $user_id, PDO::PARAM_INT);
$stmt->execute();
$booking = $stmt->fetch();

if (!$booking) {
    die("Invalid or already paid booking.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $payment_method = $_POST['payment_method'];
    $transaction_id = "TXN" . time() . rand(1000, 9999);
    
    // Begin transaction
    $pdo->beginTransaction();
    try {
        // Insert Payment
        $pay_sql = "INSERT INTO payments (booking_id, user_id, amount, payment_method, transaction_id, status) 
                    VALUES (:booking_id, :user_id, :amount, :payment_method, :transaction_id, 'Success')";
        $pay_stmt = $pdo->prepare($pay_sql);
        $pay_stmt->bindParam(":booking_id", $booking_id, PDO::PARAM_INT);
        $pay_stmt->bindParam(":user_id", $user_id, PDO::PARAM_INT);
        $pay_stmt->bindParam(":amount", $booking['total_amount']);
        $pay_stmt->bindParam(":payment_method", $payment_method, PDO::PARAM_STR);
        $pay_stmt->bindParam(":transaction_id", $transaction_id, PDO::PARAM_STR);
        $pay_stmt->execute();
        
        // Update Booking Status
        $update_sql = "UPDATE bookings SET status = 'Confirmed', payment_status = 'Completed' WHERE id = :booking_id";
        $update_stmt = $pdo->prepare($update_sql);
        $update_stmt->bindParam(":booking_id", $booking_id, PDO::PARAM_INT);
        $update_stmt->execute();
        
        $pdo->commit();
        header("location: confirmation.php?booking_id=" . $booking_id);
        exit;
    } catch (Exception $e) {
        $pdo->rollBack();
        echo "Payment failed: " . $e->getMessage();
    }
}
?>

<?php include_once "includes/header.php"; ?>

<div class="form-container" style="max-width: 500px;">
    <h2><i class="fa-regular fa-credit-card"></i> Payment Simulator</h2>
    
    <div style="background: #f8f9fa; padding: 1.5rem; text-align: center; border-radius: var(--border-radius); margin-bottom: 1.5rem;">
        <p style="font-size: 1.1rem; color: var(--light-text);">Amount Payable</p>
        <h1 style="color: var(--primary-dark); margin: 0.5rem 0;">₹<?php echo $booking['total_amount']; ?></h1>
        <p style="font-weight: bold;"><?php echo htmlspecialchars($booking['temple_name']); ?></p>
    </div>

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
        
        <div class="form-group">
            <label>Select Payment Method</label>
            <select name="payment_method" class="form-control" required>
                <option value="UPI">UPI / QR Code</option>
                <option value="Card">Credit / Debit Card</option>
                <option value="Net Banking">Net Banking</option>
            </select>
        </div>
        
        <div class="alert alert-warning" style="font-size: 0.9rem;">
            <i class="fa-solid fa-triangle-exclamation"></i> This is a dummy payment module. Clicking "Pay Now" will automatically generate a successful transaction.
        </div>
        
        <div class="form-group">
            <button type="submit" class="btn btn-success btn-block" style="font-size: 1.1rem; padding: 0.8rem;">
                <i class="fa-solid fa-lock"></i> Pay ₹<?php echo $booking['total_amount']; ?> securely
            </button>
        </div>
    </form>
</div>

<?php include_once "includes/footer.php"; ?>
