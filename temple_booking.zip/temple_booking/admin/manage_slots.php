<?php
require_once "../includes/config.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION["loggedin"]) || $_SESSION["role"] !== 'admin') {
    header("location: ../index.php");
    exit;
}

$msg = "";
$temples = $pdo->query("SELECT id, name FROM temples")->fetchAll();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_slot'])) {
    $temple_id = $_POST['temple_id'];
    $slot_date = $_POST['slot_date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $capacity = $_POST['capacity'];
    $type = $_POST['type'];
    $price = $_POST['price'];
    
    $sql = "INSERT INTO slots (temple_id, slot_date, start_time, end_time, total_capacity, available_capacity, type, price) 
            VALUES (:temple_id, :slot_date, :start_time, :end_time, :capacity, :capacity, :type, :price)";
    $stmt = $pdo->prepare($sql);
    
    if ($stmt->execute([
        ':temple_id' => $temple_id,
        ':slot_date' => $slot_date,
        ':start_time' => $start_time,
        ':end_time' => $end_time,
        ':capacity' => $capacity,
        ':type' => $type,
        ':price' => $price
    ])) {
        $msg = "<div class='alert alert-success'>Slot added successfully!</div>";
    } else {
        $msg = "<div class='alert alert-danger'>Failed to add slot.</div>";
    }
}

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $pdo->query("DELETE FROM slots WHERE id = $id");
    header("location: manage_slots.php");
    exit;
}

$slots = $pdo->query("SELECT s.*, t.name as temple_name FROM slots s JOIN temples t ON s.temple_id = t.id ORDER BY s.slot_date DESC, s.start_time ASC")->fetchAll();
?>

<?php include_once "../includes/header.php"; ?>

<div style="display: flex; gap: 2rem; margin-bottom: 2rem;">
    <!-- Sidebar -->
    <div style="width: 250px; background: var(--white); padding: 1.5rem; border-radius: var(--border-radius); box-shadow: var(--box-shadow); height: fit-content;">
        <h3 style="color: var(--secondary-color); margin-bottom: 1.5rem;"><i class="fa-solid fa-user-shield"></i> Admin Menu</h3>
        <ul style="list-style: none;">
            <li style="margin-bottom: 1rem;"><a href="index.php" style="text-decoration: none; color: var(--secondary-color);"><i class="fa-solid fa-gauge"></i> Dashboard</a></li>
            <li style="margin-bottom: 1rem;"><a href="manage_temples.php" style="text-decoration: none; color: var(--secondary-color);"><i class="fa-solid fa-vihara"></i> Manage Temples</a></li>
            <li style="margin-bottom: 1rem;"><a href="manage_slots.php" style="text-decoration: none; color: var(--primary-dark); font-weight: bold;"><i class="fa-regular fa-calendar-plus"></i> Manage Slots</a></li>
            <li style="margin-bottom: 1rem;"><a href="manage_bookings.php" style="text-decoration: none; color: var(--secondary-color);"><i class="fa-solid fa-list-check"></i> Manage Bookings</a></li>
        </ul>
    </div>
    
    <!-- Main Content -->
    <div style="flex: 1;">
        <h2>Manage Darshan & Pooja Slots</h2>
        <?php echo $msg; ?>
        
        <div class="alert alert-info" style="margin: 1.5rem 0;">
            <i class="fa-solid fa-circle-info"></i> <strong>Dynamic Booking Enabled:</strong> Slots are now automatically generated whenever a user chooses a flexible Date and Time for their Darshan or Pooja. You no longer need to manually create slots. You can view or delete existing slots below.
        </div>
        
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Temple</th>
                        <th>Type</th>
                        <th>Date & Time</th>
                        <th>Price</th>
                        <th>Capacity (Avail/Total)</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($slots as $s): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($s['temple_name']); ?></td>
                        <td>
                            <span class="badge <?php echo strtolower($s['type']) == 'darshan' ? 'badge-darshan' : 'badge-pooja'; ?>">
                                <?php echo htmlspecialchars($s['type']); ?>
                            </span>
                        </td>
                        <td><?php echo date('d M Y', strtotime($s['slot_date'])); ?> <br><small><?php echo date('h:i A', strtotime($s['start_time'])) . ' - ' . date('h:i A', strtotime($s['end_time'])); ?></small></td>
                        <td>₹<?php echo $s['price']; ?></td>
                        <td><?php echo $s['available_capacity']; ?> / <?php echo $s['total_capacity']; ?></td>
                        <td>
                            <a href="manage_slots.php?delete=<?php echo $s['id']; ?>" class="btn btn-danger" style="padding: 0.3rem 0.6rem; font-size:0.8rem;" onclick="return confirm('Delete this slot? Bookings dependent on this slot might face issues.');"><i class="fa-solid fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include_once "../includes/footer.php"; ?>
