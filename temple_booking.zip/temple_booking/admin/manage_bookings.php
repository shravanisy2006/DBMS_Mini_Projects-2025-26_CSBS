<?php
require_once "../includes/config.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION["loggedin"]) || $_SESSION["role"] !== 'admin') {
    header("location: ../index.php");
    exit;
}

if (isset($_GET['status']) && isset($_GET['id'])) {
    $status = $_GET['status'];
    $id = intval($_GET['id']);
    
    if (in_array($status, ['Pending', 'Confirmed', 'Cancelled'])) {
        $pdo->query("UPDATE bookings SET status = '$status' WHERE id = $id");
        header("location: manage_bookings.php");
        exit;
    }
}

$sql = "SELECT b.*, u.name as user_name, t.name as temple_name, s.slot_date, s.start_time 
        FROM bookings b 
        JOIN users u ON b.user_id = u.id 
        JOIN temples t ON b.temple_id = t.id 
        JOIN slots s ON b.slot_id = s.id 
        ORDER BY b.booking_date DESC";
$bookings = $pdo->query($sql)->fetchAll();
?>

<?php include_once "../includes/header.php"; ?>

<div style="display: flex; gap: 2rem; margin-bottom: 2rem;">
    <!-- Sidebar -->
    <div style="width: 250px; background: var(--white); padding: 1.5rem; border-radius: var(--border-radius); box-shadow: var(--box-shadow); height: fit-content;">
        <h3 style="color: var(--secondary-color); margin-bottom: 1.5rem;"><i class="fa-solid fa-user-shield"></i> Admin Menu</h3>
        <ul style="list-style: none;">
            <li style="margin-bottom: 1rem;"><a href="index.php" style="text-decoration: none; color: var(--secondary-color);"><i class="fa-solid fa-gauge"></i> Dashboard</a></li>
            <li style="margin-bottom: 1rem;"><a href="manage_temples.php" style="text-decoration: none; color: var(--secondary-color);"><i class="fa-solid fa-vihara"></i> Manage Temples</a></li>
            <li style="margin-bottom: 1rem;"><a href="manage_slots.php" style="text-decoration: none; color: var(--secondary-color);"><i class="fa-regular fa-calendar-plus"></i> Manage Slots</a></li>
            <li style="margin-bottom: 1rem;"><a href="manage_bookings.php" style="text-decoration: none; color: var(--primary-dark); font-weight: bold;"><i class="fa-solid fa-list-check"></i> Manage Bookings</a></li>
        </ul>
    </div>
    
    <!-- Main Content -->
    <div style="flex: 1;">
        <h2>All System Bookings</h2>
        
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>User</th>
                        <th>Temple</th>
                        <th>Date & Time</th>
                        <th>Total Amount</th>
                        <th>Payment</th>
                        <th>Status</th>
                        <th>Update Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($bookings as $b): ?>
                    <tr>
                        <td>#<?php echo str_pad($b['id'], 6, '0', STR_PAD_LEFT); ?></td>
                        <td><?php echo htmlspecialchars($b['user_name']); ?></td>
                        <td><?php echo htmlspecialchars($b['temple_name']); ?></td>
                        <td><?php echo date('d M Y', strtotime($b['slot_date'])); ?><br><small><?php echo date('h:i A', strtotime($b['start_time'])); ?></small></td>
                        <td>₹<?php echo $b['total_amount']; ?></td>
                        <td>
                            <?php if($b['payment_status'] == 'Completed'): ?>
                                <span class="badge badge-confirmed">Paid</span>
                            <?php else: ?>
                                <span class="badge badge-pending">Pending</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php 
                                $sc = 'badge-pending';
                                if($b['status']=='Confirmed') $sc = 'badge-confirmed';
                                if($b['status']=='Cancelled') $sc = 'badge-cancelled';
                            ?>
                            <span class="badge <?php echo $sc; ?>"><?php echo $b['status']; ?></span>
                        </td>
                        <td>
                            <?php if($b['status'] != 'Confirmed'): ?>
                                <a href="manage_bookings.php?id=<?php echo $b['id']; ?>&status=Confirmed" class="btn btn-outline" style="padding: 0.2rem 0.5rem; font-size: 0.8rem; color:green; border-color:green;" title="Confirm"><i class="fa-solid fa-check"></i></a>
                            <?php endif; ?>
                            <?php if($b['status'] != 'Cancelled'): ?>
                                <a href="manage_bookings.php?id=<?php echo $b['id']; ?>&status=Cancelled" class="btn btn-danger" style="padding: 0.2rem 0.5rem; font-size: 0.8rem;" title="Cancel" onclick="return confirm('Cancel this booking?');"><i class="fa-solid fa-xmark"></i></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include_once "../includes/footer.php"; ?>
