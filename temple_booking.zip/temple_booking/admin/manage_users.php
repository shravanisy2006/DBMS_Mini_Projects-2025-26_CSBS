<?php
require_once "../includes/config.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION["loggedin"]) || $_SESSION["role"] !== 'admin') {
    header("location: ../index.php");
    exit;
}

$sql = "SELECT * FROM users ORDER BY created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$users = $stmt->fetchAll();
?>

<?php include_once "../includes/header.php"; ?>

<div class="form-container wide" style="margin-top:2rem;">
    <h2 style="margin-bottom: 1.5rem;"><i class="fa-solid fa-users"></i> Manage Users</h2>
    <p style="text-align:center; color: var(--light-text); margin-bottom: 2rem;">View all registered users and their details below.</p>

    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Role</th>
                    <th>Registered On</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                    <tr>
                        <td style="color:var(--light-text);">#<?php echo htmlspecialchars($u['id']); ?></td>
                        <td style="font-weight:600; color:var(--primary-color);"><?php echo htmlspecialchars($u['name']); ?></td>
                        <td><?php echo htmlspecialchars($u['email']); ?></td>
                        <td><?php echo htmlspecialchars($u['phone']); ?></td>
                        <td>
                            <?php if($u['role'] === 'admin'): ?>
                                <span class="badge badge-admin">Admin</span>
                            <?php else: ?>
                                <span class="badge" style="background: rgba(46, 213, 115, 0.1); color: #2ed573; border: 1px solid #2ed573;">User</span>
                            <?php endif; ?>
                        </td>
                        <td style="font-size:0.85rem; color:var(--light-text);"><?php echo htmlspecialchars(date('d M Y, h:i A', strtotime($u['created_at']))); ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (count($users) == 0): ?>
                    <tr><td colspan="6" style="text-align:center;">No users found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div style="text-align: center; margin-top: 2rem;">
        <a href="index.php" class="btn btn-outline"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>
    </div>
</div>

<?php include_once "../includes/footer.php"; ?>
