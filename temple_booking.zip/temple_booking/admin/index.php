<?php
require_once "../includes/config.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION["loggedin"]) || $_SESSION["role"] !== 'admin') {
    header("location: ../index.php");
    exit;
}

// Fetch stats
$users_count = $pdo->query("SELECT COUNT(*) FROM users WHERE role='user'")->fetchColumn();
$temples_count = $pdo->query("SELECT COUNT(*) FROM temples")->fetchColumn();
$bookings_count = $pdo->query("SELECT COUNT(*) FROM bookings")->fetchColumn();
$revenue = $pdo->query("SELECT SUM(amount) FROM payments WHERE status='Success'")->fetchColumn();
?>

<?php include_once "../includes/header.php"; ?>

<div style="display: flex; gap: 2rem; margin-bottom: 2rem;">
    <!-- Sidebar -->
    <div style="width: 250px; background: var(--white); padding: 1.5rem; border-radius: var(--border-radius); box-shadow: var(--box-shadow); height: fit-content;">
        <h3 style="color: var(--secondary-color); margin-bottom: 1.5rem;"><i class="fa-solid fa-user-shield"></i> Admin Menu</h3>
        <ul style="list-style: none;">
            <li style="margin-bottom: 1rem;"><a href="index.php" style="text-decoration: none; color: var(--primary-dark); font-weight: bold;"><i class="fa-solid fa-gauge"></i> Dashboard</a></li>
            <li style="margin-bottom: 1rem;"><a href="manage_temples.php" style="text-decoration: none; color: var(--secondary-color);"><i class="fa-solid fa-vihara"></i> Manage Temples</a></li>
            <li style="margin-bottom: 1rem;"><a href="manage_slots.php" style="text-decoration: none; color: var(--secondary-color);"><i class="fa-regular fa-calendar-plus"></i> Manage Slots</a></li>
            <li style="margin-bottom: 1rem;"><a href="manage_bookings.php" style="text-decoration: none; color: var(--secondary-color);"><i class="fa-solid fa-list-check"></i> Manage Bookings</a></li>
            <li style="margin-bottom: 1rem;"><a href="manage_users.php" style="text-decoration: none; color: var(--secondary-color);"><i class="fa-solid fa-users"></i> Manage Users</a></li>
        </ul>
    </div>
    
    <!-- Main Content -->
    <div style="flex: 1;">
        <h2>Admin Dashboard</h2>
        <p style="color: var(--light-text); margin-bottom: 1.5rem;">Welcome back, System Administrator.</p>
        
        <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); margin-top: 0;">
            <div class="card" style="border-left: 4px solid var(--primary-color);">
                <div class="card-body" style="align-items: center; justify-content: center; text-align: center;">
                    <i class="fa-solid fa-users" style="font-size: 2rem; color: var(--primary-color); margin-bottom: 0.5rem;"></i>
                    <h3 style="font-size: 2rem; color: var(--secondary-color);"><?php echo $users_count; ?></h3>
                    <p style="color: var(--light-text);">Total Users</p>
                </div>
            </div>
            
            <div class="card" style="border-left: 4px solid var(--success);">
                <div class="card-body" style="align-items: center; justify-content: center; text-align: center;">
                    <i class="fa-solid fa-vihara" style="font-size: 2rem; color: var(--success); margin-bottom: 0.5rem;"></i>
                    <h3 style="font-size: 2rem; color: var(--secondary-color);"><?php echo $temples_count; ?></h3>
                    <p style="color: var(--light-text);">Total Temples</p>
                </div>
            </div>
            
            <div class="card" style="border-left: 4px solid var(--danger);">
                <div class="card-body" style="align-items: center; justify-content: center; text-align: center;">
                    <i class="fa-solid fa-ticket" style="font-size: 2rem; color: var(--danger); margin-bottom: 0.5rem;"></i>
                    <h3 style="font-size: 2rem; color: var(--secondary-color);"><?php echo $bookings_count; ?></h3>
                    <p style="color: var(--light-text);">Total Bookings</p>
                </div>
            </div>
            
            <div class="card" style="border-left: 4px solid #9c27b0;">
                <div class="card-body" style="align-items: center; justify-content: center; text-align: center;">
                    <i class="fa-solid fa-indian-rupee-sign" style="font-size: 2rem; color: #9c27b0; margin-bottom: 0.5rem;"></i>
                    <h3 style="font-size: 2rem; color: var(--secondary-color);">₹<?php echo number_format($revenue ?? 0, 2); ?></h3>
                    <p style="color: var(--light-text);">Total Revenue</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include_once "../includes/footer.php"; ?>
