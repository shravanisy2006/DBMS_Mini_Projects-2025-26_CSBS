<?php
require_once "../includes/config.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION["loggedin"]) || $_SESSION["role"] !== 'admin') {
    header("location: ../index.php");
    exit;
}

$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_temple'])) {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $location = trim($_POST['location']);
    
    $sql = "INSERT INTO temples (name, description, location) VALUES (:name, :description, :location)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(":name", $name, PDO::PARAM_STR);
    $stmt->bindParam(":description", $description, PDO::PARAM_STR);
    $stmt->bindParam(":location", $location, PDO::PARAM_STR);
    
    if ($stmt->execute()) {
        $msg = "<div class='alert alert-success'>Temple added successfully!</div>";
    } else {
        $msg = "<div class='alert alert-danger'>Failed to add temple.</div>";
    }
}

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $pdo->query("DELETE FROM temples WHERE id = $id");
    header("location: manage_temples.php");
    exit;
}

$temples = $pdo->query("SELECT * FROM temples ORDER BY created_at DESC")->fetchAll();
?>

<?php include_once "../includes/header.php"; ?>

<div style="display: flex; gap: 2rem; margin-bottom: 2rem;">
    <!-- Sidebar -->
    <div style="width: 250px; background: var(--white); padding: 1.5rem; border-radius: var(--border-radius); box-shadow: var(--box-shadow); height: fit-content;">
        <h3 style="color: var(--secondary-color); margin-bottom: 1.5rem;"><i class="fa-solid fa-user-shield"></i> Admin Menu</h3>
        <ul style="list-style: none;">
            <li style="margin-bottom: 1rem;"><a href="index.php" style="text-decoration: none; color: var(--secondary-color);"><i class="fa-solid fa-gauge"></i> Dashboard</a></li>
            <li style="margin-bottom: 1rem;"><a href="manage_temples.php" style="text-decoration: none; color: var(--primary-dark); font-weight: bold;"><i class="fa-solid fa-vihara"></i> Manage Temples</a></li>
            <li style="margin-bottom: 1rem;"><a href="manage_slots.php" style="text-decoration: none; color: var(--secondary-color);"><i class="fa-regular fa-calendar-plus"></i> Manage Slots</a></li>
            <li style="margin-bottom: 1rem;"><a href="manage_bookings.php" style="text-decoration: none; color: var(--secondary-color);"><i class="fa-solid fa-list-check"></i> Manage Bookings</a></li>
        </ul>
    </div>
    
    <!-- Main Content -->
    <div style="flex: 1;">
        <h2>Manage Temples</h2>
        <?php echo $msg; ?>
        
        <div class="form-container" style="margin: 1.5rem 0; max-width: 100%;">
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label>Temple Name</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Location</label>
                        <input type="text" name="location" class="form-control" required>
                    </div>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" class="form-control" rows="3" required></textarea>
                </div>
                <button type="submit" name="add_temple" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add New Temple</button>
            </form>
        </div>
        
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Temple Name</th>
                        <th>Location</th>
                        <th>Added On</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($temples as $t): ?>
                    <tr>
                        <td><?php echo $t['id']; ?></td>
                        <td><?php echo htmlspecialchars($t['name']); ?></td>
                        <td><?php echo htmlspecialchars($t['location']); ?></td>
                        <td><?php echo date('d M Y', strtotime($t['created_at'])); ?></td>
                        <td>
                            <a href="manage_temples.php?delete=<?php echo $t['id']; ?>" class="btn btn-danger" style="padding: 0.3rem 0.6rem; font-size:0.8rem;" onclick="return confirm('Delete this temple? All associated slots & bookings will be lost!');"><i class="fa-solid fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include_once "../includes/footer.php"; ?>
